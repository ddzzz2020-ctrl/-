import { useState, useCallback, useRef, useEffect } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import {
  Upload,
  FileSpreadsheet,
  Download,
  ChevronDown,
  History,
  Tag,
  CheckCircle2,
  AlertCircle,
  Loader2,
  X,
  RefreshCw,
} from "lucide-react";
import HistoryPanel from "@/components/HistoryPanel";
import TagsSidebar from "@/components/TagsSidebar";
import ResultPreview from "@/components/ResultPreview";

type Step = "idle" | "uploaded" | "processing" | "done" | "failed";

export default function Home() {
  const [step, setStep] = useState<Step>("idle");
  const [taskId, setTaskId] = useState<number | null>(null);
  const [columns, setColumns] = useState<string[]>([]);
  const [selectedColumn, setSelectedColumn] = useState<string>("");
  const [totalRows, setTotalRows] = useState(0);
  const [processedRows, setProcessedRows] = useState(0);
  const [resultUrl, setResultUrl] = useState<string | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [uploadedFilename, setUploadedFilename] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [showSidebar, setShowSidebar] = useState(true);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const pollRef = useRef<ReturnType<typeof setInterval> | null>(null);

  // tRPC queries
  const taskQuery = trpc.tasks.get.useQuery(
    { taskId: taskId! },
    { enabled: !!taskId && (step === "processing"), refetchInterval: 1500 }
  );

  // Poll task progress
  useEffect(() => {
    if (!taskQuery.data) return;
    const task = taskQuery.data;
    setProcessedRows(task.processedRows);
    setTotalRows(task.totalRows);
    if (task.status === "done") {
      setStep("done");
      setResultUrl(task.resultFileUrl ?? null);
      toast.success("打标完成！", { description: `共处理 ${task.totalRows} 条评论` });
    } else if (task.status === "failed") {
      setStep("failed");
      toast.error("处理失败", { description: task.errorMessage ?? "未知错误" });
    }
  }, [taskQuery.data]);

  // Upload file
  const handleFile = useCallback(async (file: File) => {
    const ext = file.name.toLowerCase().split(".").pop() ?? "";
    if (!["xlsx", "xls", "csv"].includes(ext)) {
      toast.error("格式不支持", { description: "请上传 xlsx、xls 或 csv 文件" });
      return;
    }
    if (file.size > 20 * 1024 * 1024) {
      toast.error("文件过大", { description: "文件大小不能超过 20MB" });
      return;
    }

    setUploadedFilename(file.name);
    setStep("uploaded");

    const formData = new FormData();
    formData.append("file", file);

    try {
      const resp = await fetch("/api/upload", { method: "POST", body: formData });
      if (!resp.ok) {
        const err = await resp.json();
        throw new Error(err.error ?? "上传失败");
      }
      const data = await resp.json();
      setTaskId(data.taskId);
      setColumns(data.columns ?? []);
      setSelectedColumn(data.guessedColumn ?? data.columns?.[0] ?? "");
      setTotalRows(data.totalRows ?? 0);
      toast.success("文件上传成功", { description: `检测到 ${data.totalRows} 条评论` });
    } catch (e) {
      setStep("idle");
      toast.error("上传失败", { description: e instanceof Error ? e.message : String(e) });
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const file = e.dataTransfer.files[0];
    if (file) handleFile(file);
  }, [handleFile]);

  const handleStartProcessing = async () => {
    if (!taskId || !selectedColumn) return;
    setStep("processing");
    setProcessedRows(0);
    try {
      const resp = await fetch("/api/start-task", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ taskId, commentColumn: selectedColumn }),
      });
      if (!resp.ok) {
        const err = await resp.json();
        throw new Error(err.error ?? "启动失败");
      }
    } catch (e) {
      setStep("failed");
      toast.error("启动失败", { description: e instanceof Error ? e.message : String(e) });
    }
  };

  const handleReset = () => {
    setStep("idle");
    setTaskId(null);
    setColumns([]);
    setSelectedColumn("");
    setTotalRows(0);
    setProcessedRows(0);
    setResultUrl(null);
    setUploadedFilename("");
    if (fileInputRef.current) fileInputRef.current.value = "";
  };

  const progressPct = totalRows > 0 ? Math.round((processedRows / totalRows) * 100) : 0;

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Geometric decorations */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
        <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full opacity-20"
          style={{ background: "oklch(0.85 0.06 230)" }} />
        <div className="absolute top-1/3 -left-16 w-64 h-64 rounded-full opacity-15"
          style={{ background: "oklch(0.88 0.05 10)" }} />
        <div className="absolute bottom-0 right-1/4 w-48 h-48 rounded-full opacity-10"
          style={{ background: "oklch(0.82 0.07 230)" }} />
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] rounded-full opacity-5 border-2"
          style={{ borderColor: "oklch(0.65 0.08 230)" }} />
      </div>

      {/* Header */}
      <header className="relative z-10 border-b border-border bg-card/80 backdrop-blur-sm">
        <div className="container flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg flex items-center justify-center"
              style={{ background: "oklch(0.18 0.01 250)" }}>
              <Tag className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="font-bold text-sm tracking-tight text-foreground">美妆差评打标系统</h1>
              <p className="text-xs text-muted-foreground">Beauty Review Tagger</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowSidebar(!showSidebar)}
              className="text-muted-foreground hover:text-foreground"
            >
              <Tag className="w-4 h-4 mr-1.5" />
              标签库
            </Button>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setShowHistory(!showHistory)}
              className="text-muted-foreground hover:text-foreground"
            >
              <History className="w-4 h-4 mr-1.5" />
              历史记录
            </Button>
          </div>
        </div>
      </header>

      {/* Main layout */}
      <div className="relative z-10 flex flex-1 container py-8 gap-6">
        {/* Tags sidebar */}
        {showSidebar && (
          <aside className="hidden lg:block w-56 shrink-0">
            <TagsSidebar />
          </aside>
        )}

        {/* Main content */}
        <main className="flex-1 min-w-0 space-y-6">
          {/* Hero text */}
          {step === "idle" && (
            <div className="mb-2">
              <h2 className="text-3xl font-black tracking-tight text-foreground leading-tight">
                自动语义打标
              </h2>
              <p className="text-muted-foreground mt-1 text-sm font-light">
                上传评论表格，AI 自动识别 38 个美妆差评维度
              </p>
            </div>
          )}

          {/* Upload zone */}
          {step === "idle" && (
            <div
              className={`relative border-2 border-dashed rounded-2xl p-12 text-center transition-all duration-200 cursor-pointer group
                ${isDragging
                  ? "border-primary bg-primary/5 scale-[1.01]"
                  : "border-border hover:border-primary/50 hover:bg-muted/30"
                }`}
              onDragOver={(e) => { e.preventDefault(); setIsDragging(true); }}
              onDragLeave={() => setIsDragging(false)}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".xlsx,.xls,.csv"
                className="hidden"
                onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
              />
              <div className="flex flex-col items-center gap-4">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center transition-colors
                  ${isDragging ? "bg-primary text-primary-foreground" : "bg-muted group-hover:bg-secondary"}`}>
                  <Upload className="w-7 h-7" />
                </div>
                <div>
                  <p className="font-semibold text-foreground">拖拽文件至此处，或点击上传</p>
                  <p className="text-sm text-muted-foreground mt-1">支持 Excel (.xlsx, .xls) 和 CSV 格式，最大 20MB</p>
                </div>
                <div className="flex gap-2">
                  {["xlsx", "xls", "csv"].map(ext => (
                    <span key={ext} className="px-2.5 py-1 rounded-full text-xs font-medium bg-muted text-muted-foreground border border-border">
                      .{ext}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Column selection */}
          {step === "uploaded" && (
            <div className="bg-card rounded-2xl border border-border p-6 space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                    <FileSpreadsheet className="w-5 h-5 text-secondary-foreground" />
                  </div>
                  <div>
                    <p className="font-semibold text-foreground text-sm">{uploadedFilename}</p>
                    <p className="text-xs text-muted-foreground">共 {totalRows} 条数据</p>
                  </div>
                </div>
                <Button variant="ghost" size="icon" onClick={handleReset} className="text-muted-foreground">
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">选择评论所在列</label>
                <p className="text-xs text-muted-foreground">系统已自动识别最可能的评论列，您也可以手动指定</p>
                <div className="relative">
                  <select
                    value={selectedColumn}
                    onChange={(e) => setSelectedColumn(e.target.value)}
                    className="w-full h-10 px-3 pr-8 rounded-lg border border-input bg-background text-sm appearance-none focus:outline-none focus:ring-2 focus:ring-ring"
                  >
                    {columns.map(col => (
                      <option key={col} value={col}>{col}</option>
                    ))}
                  </select>
                  <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground pointer-events-none" />
                </div>
              </div>

              <Button
                className="w-full h-11 font-semibold"
                style={{ background: "oklch(0.18 0.01 250)", color: "white" }}
                onClick={handleStartProcessing}
                disabled={!selectedColumn}
              >
                开始自动打标
              </Button>
            </div>
          )}

          {/* Processing */}
          {step === "processing" && (
            <div className="bg-card rounded-2xl border border-border p-6 space-y-5">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-secondary flex items-center justify-center">
                  <Loader2 className="w-5 h-5 text-secondary-foreground animate-spin" />
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">正在处理中…</p>
                  <p className="text-xs text-muted-foreground">
                    已处理 {processedRows} / {totalRows} 条评论
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>进度</span>
                  <span>{progressPct}%</span>
                </div>
                <Progress value={progressPct} className="h-2" />
              </div>

              <div className="flex items-start gap-2 p-3 rounded-lg bg-muted/50 text-xs text-muted-foreground">
                <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
                <span>AI 正在逐条分析评论语义，大文件处理需要几分钟，完成后将自动通知您</span>
              </div>
            </div>
          )}

          {/* Done */}
          {step === "done" && taskId && (
            <div className="space-y-4">
              <div className="bg-card rounded-2xl border border-border p-6 space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center"
                      style={{ background: "oklch(0.9 0.04 150)" }}>
                      <CheckCircle2 className="w-5 h-5" style={{ color: "oklch(0.4 0.12 150)" }} />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">打标完成</p>
                      <p className="text-xs text-muted-foreground">共处理 {totalRows} 条评论</p>
                    </div>
                  </div>
                  <Button variant="ghost" size="sm" onClick={handleReset} className="text-muted-foreground">
                    <RefreshCw className="w-4 h-4 mr-1.5" />
                    重新上传
                  </Button>
                </div>

                <div className="flex gap-3">
                  {resultUrl && (
                    <a href={resultUrl} download target="_blank" rel="noreferrer" className="flex-1">
                      <Button className="w-full h-10 font-semibold gap-2"
                        style={{ background: "oklch(0.18 0.01 250)", color: "white" }}>
                        <Download className="w-4 h-4" />
                        下载打标结果
                      </Button>
                    </a>
                  )}
                </div>
              </div>

              {/* Preview */}
              <ResultPreview taskId={taskId} />
            </div>
          )}

          {/* Failed */}
          {step === "failed" && (
            <div className="bg-card rounded-2xl border border-destructive/30 p-6 space-y-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-destructive/10 flex items-center justify-center">
                  <AlertCircle className="w-5 h-5 text-destructive" />
                </div>
                <div>
                  <p className="font-semibold text-foreground text-sm">处理失败</p>
                  <p className="text-xs text-muted-foreground">请检查文件格式后重试</p>
                </div>
              </div>
              <Button variant="outline" onClick={handleReset} className="w-full">
                重新上传
              </Button>
            </div>
          )}

          {/* How it works */}
          {step === "idle" && (
            <div className="grid grid-cols-3 gap-4 mt-4">
              {[
                { step: "01", title: "上传文件", desc: "支持 Excel 和 CSV 格式的评论数据" },
                { step: "02", title: "AI 语义分析", desc: "LLM 深度理解每条评论的负面含义" },
                { step: "03", title: "下载结果", desc: "带标签的完整表格，一键导出" },
              ].map((item) => (
                <div key={item.step} className="bg-card rounded-xl border border-border p-4">
                  <div className="text-xs font-black text-muted-foreground/50 mb-2 tracking-widest">{item.step}</div>
                  <p className="font-semibold text-sm text-foreground">{item.title}</p>
                  <p className="text-xs text-muted-foreground mt-1 font-light">{item.desc}</p>
                </div>
              ))}
            </div>
          )}
        </main>

        {/* History panel */}
        {showHistory && (
          <aside className="hidden xl:block w-72 shrink-0">
            <HistoryPanel onSelectTask={(id: number) => {
              setTaskId(id);
              setStep("done");
              setShowHistory(false);
            }} />
          </aside>
        )}
      </div>

      {/* Mobile history drawer */}
      {showHistory && (
        <div className="xl:hidden fixed inset-0 z-50 bg-black/40" onClick={() => setShowHistory(false)}>
          <div className="absolute right-0 top-0 bottom-0 w-80 bg-background shadow-xl p-4 overflow-y-auto"
            onClick={(e) => e.stopPropagation()}>
            <HistoryPanel onSelectTask={(id) => {
              setTaskId(id);
              setStep("done");
              setShowHistory(false);
            }} />
          </div>
        </div>
      )}
    </div>
  );
}
