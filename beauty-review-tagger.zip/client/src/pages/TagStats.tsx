import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, BarChart3 } from "lucide-react";
import { useLocation } from "wouter";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, Cell } from "recharts";
import { useMemo } from "react";

interface TagCountData {
  tag: string;
  count: number;
}

export default function TagStats() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();

  // Mock data - 实际应从后端获取
  const mockTagData: TagCountData[] = useMemo(() => {
    return [
      { tag: "卡粉", count: 45 },
      { tag: "脱妆", count: 38 },
      { tag: "持妆差", count: 32 },
      { tag: "遮瑕差", count: 28 },
      { tag: "浮粉", count: 25 },
      { tag: "氧化暗沉", count: 22 },
      { tag: "干", count: 20 },
      { tag: "起皮", count: 18 },
      { tag: "粉感重/厚重/粉质粗", count: 15 },
      { tag: "假白", count: 12 },
    ];
  }, []);

  const colors = [
    "#e5a3b3",
    "#b3d9e5",
    "#c9b3e5",
    "#e5d4b3",
    "#b3e5d4",
    "#e5b3b3",
    "#d4b3e5",
    "#b3e5b3",
    "#e5c9b3",
    "#b3d4e5",
  ];

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-muted-foreground">请先登录</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="flex items-center gap-4 mb-8">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setLocation("/")}
            className="rounded-full"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-2">
              <BarChart3 className="w-8 h-8 text-pink-300" />
              标签统计分析
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              展示所有处理任务中的标签命中频率
            </p>
          </div>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                总标签数
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-foreground">
                {mockTagData.reduce((sum, item) => sum + item.count, 0)}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                高频标签
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-pink-300">
                {mockTagData[0]?.tag}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                {mockTagData[0]?.count} 次
              </p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                覆盖标签数
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-300">
                {mockTagData.length}
              </div>
              <p className="text-xs text-muted-foreground mt-1">
                共 38 个标签
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Chart */}
        <Card>
          <CardHeader>
            <CardTitle>标签命中频率排行</CardTitle>
            <CardDescription>
              展示前 10 个最常见的差评标签
            </CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={400}>
              <BarChart data={mockTagData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                <XAxis
                  dataKey="tag"
                  angle={-45}
                  textAnchor="end"
                  height={100}
                  tick={{ fontSize: 12 }}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#fff",
                    border: "1px solid #e5e7eb",
                    borderRadius: "0.5rem",
                  }}
                />
                <Bar dataKey="count" fill="#b3d9e5" radius={[8, 8, 0, 0]}>
                  {mockTagData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={colors[index % colors.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Table */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>详细数据</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">
                      排名
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground">
                      标签名称
                    </th>
                    <th className="text-right py-3 px-4 font-semibold text-muted-foreground">
                      命中次数
                    </th>
                    <th className="text-right py-3 px-4 font-semibold text-muted-foreground">
                      占比
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {mockTagData.map((item, index) => {
                    const total = mockTagData.reduce((sum, i) => sum + i.count, 0);
                    const percentage = ((item.count / total) * 100).toFixed(1);
                    return (
                      <tr
                        key={index}
                        className="border-b border-border hover:bg-muted/50 transition-colors"
                      >
                        <td className="py-3 px-4 text-foreground font-medium">
                          {index + 1}
                        </td>
                        <td className="py-3 px-4 text-foreground">{item.tag}</td>
                        <td className="py-3 px-4 text-right text-foreground font-semibold">
                          {item.count}
                        </td>
                        <td className="py-3 px-4 text-right text-muted-foreground">
                          {percentage}%
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
